// Enrico Convento Id: 2023572
// Dataset preparation code
// Instruction in file README_Training



#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/core/types.hpp>
#include <opencv2/imgproc.hpp>
#include "opencv2/ximgproc/segmentation.hpp"
#include "json.hpp"
#include <fstream>
#include <vector>
#include <algorithm>   

using namespace cv;
using namespace std;
using namespace cv::ximgproc::segmentation;
using json = nlohmann::json;

const char* keys = "{folder_path m        |<none>| folder   }";


vector<String> stringTokenizer(string s, string del)
{
    int start = 0;
    int end = s.find(del);
    vector<String> tokens;
    while (end != -1) {
        tokens.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }
    return tokens;
}

vector<Rect> selectiveSearch(Mat img) {

    setUseOptimized(true);
    Ptr<SelectiveSearchSegmentation> ss = createSelectiveSearchSegmentation();
    ss->setBaseImage(img);
    ss->switchToSelectiveSearchFast();
    std::vector<Rect> rects;
    ss->process(rects);

    return rects;
}

// Compute intersection over union of two given boxes
double IoU(Rect boxA, Rect boxB) {

    Point2d A = Point2d(max(boxA.tl().x, boxB.tl().x), max(boxA.tl().y, boxB.tl().y));
    Point2d B = Point2d(min(boxA.br().x, boxB.br().x), min(boxA.br().y, boxB.br().y));

    // compute the area of intersection rectangle
    double interArea = abs(max(B.x - A.x, 0.0) * max(B.y - A.y, 0.0));
    if (interArea == 0)
        return 0;
    // compute the area of both the prediction and ground-truth
    // rectangles
    double boxAArea = abs(boxA.height * boxA.width);
    double boxBArea = abs(boxB.height * boxB.width);

    double iou = interArea / float(boxAArea + boxBArea - interArea);
    return iou;
}

int main(int argc, char **argv) {

    CommandLineParser parser(argc, argv, keys);
    parser.about("Use this script to run object detection using RCNN in OpenCV.");
    String folder_path;
    if(argc < 2){
        cout << "\n------------------Incorrect input arguments--------------------\n\n"<< endl;
        cout << "Use the command:"<< endl;
        cout << "./detector_training  --folder_path=utility_folder path"<< endl;
        cout << "\n\nAs shown in the README file\n\n---------------------------------------------------------------\n\n"<< endl;
        return -1;
    }

    if(parser.has("folder_path"))
    {
        // Open the image file
        folder_path  = parser.get<String>("folder_path");
    }


    cout << "Dataset processing ... \n" << endl;

    vector<String> filenames;
    String path = folder_path+"/training_images_gt";       // ground truth folder path + images
    glob(path + "/*.jpg", filenames, false);
    json ann_json;
    Mat img;
    int count_boat = 0;
    int count_non_boat = 0;


    for(const auto& fn : filenames){

        img = imread(fn);
        cout << "Analyzing image " << fn << " ..." << endl;

        vector<Rect> ground_truth;
        vector<String> tokens = stringTokenizer(fn, ".");
        string json_path = tokens[0] + ".jpg___objects.json";

        // .json file  reading
        std::ifstream boat_json(json_path, std::ifstream::binary);
        boat_json >> ann_json;
        int j = 0;

        while(!ann_json["instances"][j]["points"].empty()) {

            Mat tmp;
            auto points = ann_json["instances"][j]["points"];

            if (points["x1"] < 0)
                points["x1"] = 0;
            if (points["y1"] < 0)
                points["y1"] = 0;
            if (points["x2"] > img.cols)
                points["x2"] = img.cols;
            if (points["y2"] > img.rows)
                points["y2"] = img.rows;

            Rect box = Rect(Point2i(points["x1"], points["y1"]), Point2i(points["x2"], points["y2"]));
            ground_truth.push_back(box);
            resize(img(box), tmp, Size(224,224));
            String boat_path = folder_path + "/boat/"  + to_string(count_boat) + ".jpg";
            imwrite(boat_path, tmp);
            j++;
            count_boat++;
        }

        vector<Rect> rects = selectiveSearch(img); // running selective search algorithm
        int falsecounter = 0;
        int flag = 0;

        // Positive/negative samples extraction
        for (int i = 0; i < rects.size(); i++) {
            if (i < 4000 and flag == 0) {
                for (const auto& gtval : ground_truth) {
                    double iou = IoU(gtval, rects[i]);
                    if (falsecounter < 5)
                        if (iou < 0.3) {
                            Mat tmp;
                            resize(img(rects[i]), tmp, Size(224,224));
                            String boat_path = folder_path + "/non_boat/" + to_string(count_non_boat) + ".jpg";
                            imwrite(boat_path, tmp);
                            falsecounter += 1;
                            count_non_boat += 1;
                        }
                    else
                        flag = 1;
                }
            }
        }

        cout << "Image acquired ... " << endl;
    }



    cout << "\nDataset preparation completed" << endl;

    waitKey(0);
    return 0;
}
