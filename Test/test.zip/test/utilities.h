

#ifndef BOAT_DETECTOR_UTILITIES_H
#define BOAT_DETECTOR_UTILITIES_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/core/types.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/dnn.hpp>
#include "opencv2/ximgproc/segmentation.hpp"
#include "json.hpp"
#include <fstream>
#include <Python.h>
#include <opencv2/objdetect.hpp>

#include <vector>
#include <numeric>      
#include <algorithm>    
#include <bits/stdc++.h>

using namespace cv;
using namespace std;
using json = nlohmann::json;
using namespace cv::ximgproc::segmentation;
using namespace dnn;

class utilities {

public:

    static Mat histEqualization(Mat img);

    static Mat GaussianSmoothing(Mat img, int ksize, int sigma);

    static Mat imgPreprocessing(Mat img, int ksize, int sigma, bool hist_eq, bool smooth);

    static vector<Rect> selectiveSearch(Mat src);

    static vector<int> sortIndexes(const vector<float> &v);

    static Mat drawBoundingBoxes(Mat src, vector<Rect> boxes, Scalar color, int thickness);

    static Mat computeDensityMap(Mat density, vector<Rect> boxes);

    static vector<Rect> densityThresh(Mat src, vector<Rect> boxes, int th);

    static vector<Rect> runNMS(vector<Rect> boxes, vector<float> confidences, float conf_th, float nms_th,  bool &nms);

    static double IoU(Rect boxA, Rect boxB);

    static vector<String> stringTokenizer(string s, string del);

    static map<String, vector<vector<float>>> getGT(String json_path);

    static vector<Rect> getGTBBoxes(map<String, vector<vector<float>>> ground_truth, String image_path);

    static tuple<float, int> getIoU(Rect gt_box, vector<Rect> predictions);

    static Mat drawGT(Mat src, vector<Rect> gt_bboxes, vector<Rect> predictions);

    static tuple< vector<Rect>,vector<float> > argSort(vector<Rect> rects, vector<float> prob, Mat src);

    static vector<float> runDNN( vector<Rect> rects, int numRects,Mat src , String folder_path);

   
};


#endif //BOAT_DETECTOR_UTILITIES_H
