// Enrico Convento ID: 2023572

#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/core/types.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/dnn.hpp>
#include "opencv2/ximgproc/segmentation.hpp"
#include "json.hpp"
#include <fstream>
#include <vector>
#include <numeric>      
#include <algorithm>    

#include "utilities.h"

using namespace cv;
using namespace std;
using json = nlohmann::json;
using namespace cv::ximgproc::segmentation;
using namespace dnn;


// Histogram equalization 
Mat utilities::histEqualization(Mat src) {

    vector<Mat> rgb_planes(src.channels());
    split(src, rgb_planes);

    vector<Mat> rgb_eq(src.channels());
    Mat img_eq;

    for(int i = 0; i < 3; i++)
        equalizeHist(rgb_planes[i], rgb_eq[i]);

    merge(rgb_eq, img_eq);

    return img_eq;
}

// Gaussian smoothing
Mat utilities::GaussianSmoothing(Mat src, int ksize, int sigma) {

    Mat dst;
    GaussianBlur(src, dst, Size (ksize, ksize), sigma, 0, cv::BORDER_DEFAULT);

    return dst;
}

// This function includes the two functions shown above
Mat utilities::imgPreprocessing(Mat src, int ksize, int sigma, bool hist_eq, bool smooth) {

    if (hist_eq)
        src = histEqualization(src);
    if (smooth)
        src = GaussianSmoothing(src, ksize, sigma);

    return src;
}

// This function implement the selective search algorithm
vector<Rect> utilities::selectiveSearch(Mat src) {

    setUseOptimized(true);
    Ptr<SelectiveSearchSegmentation> ss = createSelectiveSearchSegmentation();
    ss->setBaseImage(src);
    ss->switchToSelectiveSearchFast();
    std::vector<Rect> rects;
    ss->process(rects);
    std::cout << "Total Number of Region Proposals: " << rects.size() << std::endl;

    return rects;
}

vector<int> utilities::sortIndexes(const vector<float> &v) {

    vector<int> idx(v.size());
    iota(idx.begin(), idx.end(), 0);

    stable_sort(idx.begin(), idx.end(),[&v](int i1, int i2) {return v[i1] > v[i2];});

    return idx;
}

// This function draw the bounding boxes on a given image given the set of boxes
Mat utilities::drawBoundingBoxes(Mat src, vector<Rect> boxes, Scalar color, int thickness) {

    Mat dst = src.clone();

    for (size_t i = 0; i < boxes.size(); i++)
        rectangle(dst, boxes[i], color, thickness);

    return dst;
}

// This function extract the density map of rectangles given in input
// This is used in the last part of the algorithm
Mat utilities::computeDensityMap(Mat density, vector<Rect> boxes) {
    for (int i = 0; i < boxes.size(); ++i) {
        cv::operator+=(density(boxes[i]),Scalar(1));
    }
    return density;
}


// Implement the threshold, this function merges rectangles, also this is part of
// the last part of the algorithm
vector<Rect> utilities::densityThresh(Mat src, vector<Rect> boxes, int th){

    Mat dst = src.clone();
    Mat density = Mat::zeros(src.rows, src.cols, CV_8U);

    density = computeDensityMap(density,boxes);
    Mat labels(src.size(), CV_32S);
    int nLabels;
    Mat bw = density > th; // Thresholding

    nLabels = connectedComponents(bw, labels, 8);
    // Piece of code used to draw and show connected componendts
    /*
    std::vector<Vec3b> colors(nLabels);
    colors[0] = Vec3b(0, 0, 0);     //background
    for(int label = 1; label < nLabels; ++label){
        colors[label] = Vec3b( (rand()&255), (rand()&255), (rand()&255) );
    }
    Mat dstLabel(src.size(), CV_8UC3);
    for(int r = 0; r < dstLabel.rows; ++r){
        for(int c = 0; c < dstLabel.cols; ++c){
            int label = labels.at<int>(r, c);
            Vec3b &pixel = dstLabel.at<Vec3b>(r, c);
            pixel = colors[label];
        }
    }
    imshow( "Connected Components", dstLabel );*/

    // Merge boxes
    vector<Rect> merged_boxes;
    for(int i = 1; i < nLabels; i++){
        Mat findNonZeros = labels==i;

        vector<Point2i> coord;
        findNonZero(findNonZeros, coord);

        int minx = INT_MAX;
        int miny = INT_MAX;
        int maxx = 0;
        int maxy = 0;

        for(int j = 0; j < coord.size(); j++) {
            if (coord[j].x < minx)
                minx = coord[j].x;
            if (coord[j].y < miny)
                miny = coord[j].y;
            if (coord[j].x > maxx)
                maxx = coord[j].x;
            if (coord[j].y > maxy)
                maxy = coord[j].y;
        }

        merged_boxes.push_back(Rect(Point2i(minx, miny),Point2i(maxx, maxy)));
    }
    cout << "Number of boxes after thresholding: " << merged_boxes.size() <<endl;

    return merged_boxes;
}

// Implement Non maxima suppression
vector<Rect> utilities::runNMS(vector<Rect> boxes, vector<float> confidences, float conf_th, float nms_th, bool &nms) {

    vector<Rect> nms_boxes;
    vector<int> indices;
    
    NMSBoxes(boxes, confidences, conf_th, nms_th, indices);

    for (size_t i = 0; i < indices.size(); i++) {
        int idx = indices[i];
        nms_boxes.push_back(boxes[idx]);
    }
    cout << "Number of boxes after NMS: " << nms_boxes.size() <<endl;
    if(nms_boxes.size() < 11)
        nms = true;
    return nms_boxes;
}

double utilities::IoU(Rect boxA, Rect boxB) {

    Point2d A = Point2d(max(boxA.tl().x, boxB.tl().x), max(boxA.tl().y, boxB.tl().y));
    Point2d B = Point2d(min(boxA.br().x, boxB.br().x), min(boxA.br().y, boxB.br().y));

    // compute the area of intersection rectangle
    double interArea = abs(max(B.x - A.x, 0.0) * max(B.y - A.y, 0.0));
    if (interArea == 0)
        return 0;
    // compute the area of both the prediction and ground-truth
    // rectangles
    double boxAArea = abs(boxA.height * boxA.width);
    double boxBArea = abs(boxB.height * boxB.width);

    // compute the intersection over union by taking the intersection
    // area and dividing it by the sum of prediction + ground-truth
    // areas - the interesection area
    double iou = interArea / float(boxAArea + boxBArea - interArea);
    return iou;
}


// Split a string in his tokens
vector<String> utilities::stringTokenizer(string s, string del)
{
    int start = 0;
    int end = s.find(del);
    vector<String> tokens;
    while (end != -1) {
        tokens.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }
    return tokens;
}

// Extract ground truth files from the json files and save in a structure
map<String, vector<vector<float>>> utilities::getGT(String json_path) {

    json data;
    std::ifstream boats_file(json_path, std::ifstream::binary);
    boats_file >> data;

    int i = 0;
    int image_id = 1;
    vector<vector<float>> annotations;
    vector<String> images;
    map<String, vector<vector<float>>> ground_truth;

    while(true){
        if(!data["annotations"][i]["bbox"].empty()) {
            while(data["annotations"][i]["image_id"] == image_id){
                annotations.push_back(data["annotations"][i]["bbox"]);
                i++;
            }
            ground_truth.insert({data["images"][image_id-1]["file_name"], annotations});
            annotations.clear();
            image_id++;
        }
            else
            break;
    }

    return ground_truth;
}


// Extract ground truth for a given image
vector<Rect> utilities::getGTBBoxes(map<String, vector<vector<float>>> ground_truth, String image_path) {

    vector<Rect> bboxes = {};
    vector<String> tokens = stringTokenizer(image_path + "/", "/");
    String image_name = tokens[tokens.size()-1];

    if (ground_truth.find(image_name) == ground_truth.end())
        return bboxes;

    auto itr = ground_truth.find(image_name);
    vector<vector<float>> value = itr->second;

    for (int i = 0; i < value.size(); i++) {
        int x1 = value[i][0];
        int y1 = value[i][1];
        int x2 = value[i][0]+value[i][2];
        int y2 = value[i][1]+value[i][3];
        bboxes.push_back(Rect(Point2i(x1,y1), Point2i(x2,y2)));
    }

    return bboxes;
}

// Return the IoU associated to the right bounding box
tuple<float, int> utilities::getIoU(Rect gt_box, vector<Rect> predictions) {

    float iou_max = -1;
    int bbox_index;
    for (int j = 0; j < predictions.size(); j++) {
        float tmp = IoU(gt_box, predictions[j]);
        if (tmp > iou_max) {
            iou_max = tmp;
            bbox_index = j;
        }
    }

    tuple<float, int> output = {iou_max, bbox_index};
    return output;
}


// Draw ground truth boxes
Mat utilities::drawGT(Mat src, vector<Rect> gt_bboxes, vector<Rect> predictions) {

    Mat dst = src.clone();

    for (const auto& box : gt_bboxes) {

        rectangle(dst, box, Scalar(255,0,0),2);
        tuple<float, int> iou_data = getIoU(box, predictions);
        float iou_max = get<0>(iou_data);
        int bbox_index = get<1>(iou_data);

        int baseLine;
        Size labelSize = getTextSize(to_string(iou_max), FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
        int top = max(predictions[bbox_index].tl().y, labelSize.height);
        rectangle(dst, Point2i(predictions[bbox_index].tl().x, top - round(1.5*labelSize.height)), Point(predictions[bbox_index].tl().x + round(1.5*labelSize.width), top + baseLine), Scalar(255, 255, 255), FILLED);
        putText(dst, to_string(iou_max), predictions[bbox_index].tl(), FONT_HERSHEY_SIMPLEX, 0.75, Scalar(0,0,0),1);
    }

    return dst;
}

tuple< vector<Rect>,vector<float> > utilities::argSort(vector<Rect> rects, vector<float> prob, Mat src){
    vector<Rect> boxes;
    vector<float> confidences;
    int upto = 300;
    int count = 1;
    Mat img_out = src.clone();
    for(const auto& i: utilities::sortIndexes(prob)) {

        rectangle(img_out, rects[i], Scalar(0, 255, 0));
        boxes.push_back(rects[i]);
        confidences.push_back((float)prob[i]);
        count +=1;
        if (count > upto)
            break;
        imshow("Model outputs:", img_out);
    }
    cout << "Number of selected boxes: "<< boxes.size() << endl;
    return make_tuple(boxes,confidences);
}

// Run the model
vector<float> utilities::runDNN( vector<Rect> rects, int numRects,Mat src , String folder_path){
    Net net =readNetFromTensorflow(folder_path + "/model.pb");
    Mat blob;
    Mat imout = src.clone();
    Mat timage, resized;
    vector<Mat> outs;
    vector<float> prob;

    for(int i=0; i < rects.size(); i++){
        if (i<numRects) {
            timage = src(rects[i]);
            resize(timage, resized, Size(224,224), cv::INTER_AREA);
            blobFromImage(resized, blob, 1.5, Size(224,224), 0);
            net.setInput(blob);
            net.forward(outs);
            prob.push_back((outs[0]).at<float>(0,0));
        }

    }
    return prob;
}


