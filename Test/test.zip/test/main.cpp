// Enrico Convento ID: 2023572
// Test program, the instruction needed to run in can be found in the file README_Test

#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/core/types.hpp>

#include "json.hpp"
#include <map>
#include <vector>
#include "utilities.h"

const char* keys = "{image i        |<none>| input image   }";

using namespace cv;
using namespace std;
using json = nlohmann::json;
using namespace cv::ximgproc::segmentation;
using namespace dnn;


int main(int argc, const char* argv[]) {

    CommandLineParser parser(argc, argv, keys);
    parser.about("Use this script to run object detection using RCNN in OpenCV.");
    String image_path;
    String folder_path = "../data";
    if(argc < 2){
        cout << "\n------------------Incorrect input arguments--------------------\n\n"<< endl;
        cout << "Use the command:"<< endl;
        cout << "./boat_detector --image=image_path "<< endl;
        cout << "\n\n( example --image=/-------/image.jpg)\n\n---------------------------------------------------------------\n\n"<< endl;
        return -1;
    }

    if (parser.has("image"))
    {
        // Open the image file
        image_path  = parser.get<String>("image");
    }


    Mat img = imread( image_path, IMREAD_COLOR);
    cout<< "Loading the input image ... \n\n------------ Input image -------------\nPress any key to continue ...\n\n" << endl;
    imshow("Input image:",img);
    // Pre-preocess the input image
    Mat image = utilities::imgPreprocessing(img, 3, 1, 0, 1);
    waitKey(0);


    // Run the selective search algorithm
    cout<< "------ Running Selective Search ------\nThis process could need some time" << endl;
    vector<Rect> rects = utilities::selectiveSearch(image); // run SS.

    Mat img_ss = utilities::drawBoundingBoxes(img, rects, Scalar(0,255,0), 1);
    imshow("Selective search result:", img_ss);
    cout<< "Press any key to continue ...\n\n" << endl;
    waitKey(0);
    destroyAllWindows();


    int numRects = 3000; // Limit the number of region for time computations

    // Running the model
    cout<< "------------ Running DNN -------------\nThis process could need some time" << endl;
    vector<float> prob = utilities::runDNN(rects,numRects,img, folder_path);

    tuple<vector<Rect> ,vector<float> > boxconf = utilities::argSort(rects, prob, img); // Sorting in order of confidence
    vector<Rect> boxes = get<0>(boxconf);
    vector<float> confidences = get<1>(boxconf);

///////////////////////////////NMS//////////////////////////////////////////

    float confThreshold = 0.2; // Confidence threshold
    float nmsThreshold = 0.95;  // Non-maximum suppression threshold
    bool nms = false;
    vector<Rect> box_nms = utilities::runNMS(boxes, confidences, confThreshold, nmsThreshold, nms);

////////////////////////// EDGE THRESDOLDING /////////////////////////////////////////
    cout<< "\n\n---------- Edge thresholding ---------" << endl;
    vector<Rect> rect_canny = box_nms;
    Mat refined_image = img.clone(); 
    Mat edges(img.size(), img.type()),img_blurred = img.clone();
    GaussianBlur(img_blurred, img_blurred, Size(9, 9), 3, 3);

    Canny(img_blurred, edges, 50, 90, 3, true);
    cvtColor(edges, edges, COLOR_BGR2RGB);
    Mat edges_roi = edges.clone();
    vector<Rect> refined_boxes;
    for (int i = 0; i < rect_canny.size(); i++)
    {
        Rect  roi(rect_canny[i].x, rect_canny[i].y, rect_canny[i].width, rect_canny[i].height);
        Mat out = edges_roi(roi);

        cvtColor(out, out, COLOR_RGB2GRAY);
        int nonzero = countNonZero(out);
        if (nonzero > 0.009 * out.cols * out.rows)                     
            refined_boxes.push_back(rect_canny[i]);                     

    }

    for (auto&& rf : refined_boxes)
    {
        rectangle(refined_image, rf, cv::Scalar(0, 0, 255), 2);
    }
    imshow("Edge thresolding result:", refined_image);
    cout<< "Press any key to continue ..." << endl;
    waitKey(0);
    destroyAllWindows();

    

        

    
    //////////////////////////DENSITY THRESHOLDING//////////////////////////////////
    Mat img_out = img.clone();
    cout<< "------------- Processing ------------" << endl;
    vector<Rect> predictions;
    if(!nms)
        predictions = utilities::densityThresh(img, refined_boxes, 4);
    else
        predictions = refined_boxes;

    if(predictions.size() == 0){
        cout << "No boat detected" << endl;
        cout<< "Press any key to stop the execution ..." << endl;
        waitKey(0);
        destroyAllWindows();
        return 0;
    }
    img_out = utilities::drawBoundingBoxes(img, predictions, Scalar(0,0,255), 2);
    
    Mat dst = img_out.clone();
    ///////////////////////////// GT control ///////////////////////////////////////////////
    map<String, vector<vector<float>>> gt_kaggle = utilities::getGT(folder_path+"/GT/COCO_Training_Kaggle.json");
    map<String, vector<vector<float>>> gt_mar = utilities::getGT(folder_path+"/GT/COCO_Training_MAR.json");
    map<String, vector<vector<float>>> gt_mar_test = utilities::getGT(folder_path+"/GT/mar_annotations_test.json");

    
    vector<Rect> gt_bboxes_kaggle = utilities::getGTBBoxes(gt_kaggle, image_path);

    if (gt_bboxes_kaggle.empty()) {

        vector<Rect> gt_bboxes_mar_test = utilities::getGTBBoxes(gt_mar_test, image_path);

        if (gt_bboxes_mar_test.empty()) {

            vector<Rect> gt_bboxes_mar = utilities::getGTBBoxes(gt_mar, image_path);

            if (gt_bboxes_mar.empty())
                cout << "Ground truth not available" << endl;
            else
                dst = utilities::drawGT(img_out, gt_bboxes_mar, predictions);
        }
        else
            dst = utilities::drawGT(img_out, gt_bboxes_mar_test, predictions);
    }
    else
        dst = utilities::drawGT(img_out, gt_bboxes_kaggle, predictions);

    imshow("Finale result:",dst);

    cout<< "Press any key to stop the execution ..." << endl;
    waitKey(0);
    destroyAllWindows();
    return 0;
}

